from setuptools import setup, find_packages

setup(
    name         = 'frameworkcITA',
    version      = '1.0',
    author       = 'Equipe AIAA ITA',
    packages     = find_packages(),
)
